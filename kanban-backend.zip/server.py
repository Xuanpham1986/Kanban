from __future__ import annotations

import base64
import hashlib
import hmac
import json
import mimetypes
import os
import secrets
import sqlite3
import sys
import uuid
from datetime import date, datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = DATA_DIR / "uploads"
DB_PATH = DATA_DIR / "kanban.sqlite3"

COLUMNS = {"backlog", "doing", "review", "done"}
PRIORITIES = {"low", "medium", "high"}
ROLES = {"admin", "manager", "member"}
PBKDF2_ITERATIONS = 210_000


def main() -> None:
    port = int(sys.argv[1]) if len(sys.argv) > 1 else int(os.environ.get("PORT", "8000"))
    host = "0.0.0.0" if os.environ.get("PORT") else "127.0.0.1"
    init_db()
    server = ThreadingHTTPServer((host, port), KanbanHandler)
    print(f"Kanban server running at http://{host}:{port}")
    server.serve_forever()


def connect() -> sqlite3.Connection:
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def init_db() -> None:
    DATA_DIR.mkdir(exist_ok=True)
    UPLOAD_DIR.mkdir(exist_ok=True)
    with connect() as db:
        db.execute(
            """
            CREATE TABLE IF NOT EXISTS tasks (
              id TEXT PRIMARY KEY,
              title TEXT NOT NULL,
              description TEXT NOT NULL DEFAULT '',
              status TEXT NOT NULL,
              priority TEXT NOT NULL,
              owner TEXT NOT NULL DEFAULT '',
              due_date TEXT NOT NULL DEFAULT '',
              tags TEXT NOT NULL DEFAULT '[]',
              report_file_name TEXT NOT NULL DEFAULT '',
              report_file_path TEXT NOT NULL DEFAULT '',
              report_file_size INTEGER NOT NULL DEFAULT 0,
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL
            )
            """
        )
        migrate_tasks_table(db)
        backfill_done_reports(db)
        db.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
              id TEXT PRIMARY KEY,
              display_name TEXT NOT NULL,
              username TEXT NOT NULL UNIQUE,
              email TEXT NOT NULL DEFAULT '',
              role TEXT NOT NULL DEFAULT 'member',
              is_active INTEGER NOT NULL DEFAULT 1,
              password_hash TEXT NOT NULL,
              password_changed_at TEXT NOT NULL,
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL
            )
            """
        )
        if db.execute("SELECT COUNT(*) FROM tasks").fetchone()[0] == 0:
            seed_tasks(db)
        if db.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
            seed_users(db)


def seed_tasks(db: sqlite3.Connection) -> None:
    today = date.today()
    rows = [
        {
            "title": "Phác thảo luồng tạo dự án",
            "description": "Làm rõ các bước người dùng cần đi qua trước khi tạo bảng công việc mới.",
            "status": "backlog",
            "priority": "medium",
            "owner": "Minh",
            "due_date": today + timedelta(days=5),
            "tags": ["UX", "Planning"],
        },
        {
            "title": "Xây dựng API danh sách thẻ",
            "description": "Chuẩn hóa dữ liệu trả về để frontend có thể lọc theo trạng thái và người phụ trách.",
            "status": "doing",
            "priority": "high",
            "owner": "An",
            "due_date": today + timedelta(days=2),
            "tags": ["Backend"],
        },
        {
            "title": "Rà soát giao diện mobile",
            "description": "Kiểm tra các cột, nút hành động và dialog trên màn hình nhỏ.",
            "status": "review",
            "priority": "medium",
            "owner": "Linh",
            "due_date": today + timedelta(days=1),
            "tags": ["UI", "QA"],
        },
        {
            "title": "Chốt quy ước nhãn công việc",
            "description": "Thống nhất bộ nhãn dùng chung cho nhóm sản phẩm.",
            "status": "done",
            "priority": "low",
            "owner": "Huy",
            "due_date": today - timedelta(days=1),
            "tags": ["Process"],
        },
    ]
    now = now_iso()
    for row in rows:
        task_id = str(uuid.uuid4())
        report = seed_report_file(task_id) if row["status"] == "done" else {"name": "", "path": "", "size": 0}
        db.execute(
            """
            INSERT INTO tasks
              (id, title, description, status, priority, owner, due_date, tags,
               report_file_name, report_file_path, report_file_size, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                task_id,
                row["title"],
                row["description"],
                row["status"],
                row["priority"],
                row["owner"],
                row["due_date"].isoformat(),
                json.dumps(row["tags"]),
                report["name"],
                report["path"],
                report["size"],
                now,
                now,
            ),
        )


def migrate_tasks_table(db: sqlite3.Connection) -> None:
    columns = {row["name"] for row in db.execute("PRAGMA table_info(tasks)").fetchall()}
    migrations = {
        "report_file_name": "ALTER TABLE tasks ADD COLUMN report_file_name TEXT NOT NULL DEFAULT ''",
        "report_file_path": "ALTER TABLE tasks ADD COLUMN report_file_path TEXT NOT NULL DEFAULT ''",
        "report_file_size": "ALTER TABLE tasks ADD COLUMN report_file_size INTEGER NOT NULL DEFAULT 0",
    }
    for column, statement in migrations.items():
        if column not in columns:
            db.execute(statement)


def backfill_done_reports(db: sqlite3.Connection) -> None:
    rows = db.execute(
        "SELECT id FROM tasks WHERE status = 'done' AND report_file_path = ''"
    ).fetchall()
    for row in rows:
        report = seed_report_file(row["id"])
        db.execute(
            """
            UPDATE tasks
            SET report_file_name = ?, report_file_path = ?, report_file_size = ?
            WHERE id = ?
            """,
            (report["name"], report["path"], report["size"], row["id"]),
        )


def seed_report_file(task_id: str) -> dict:
    file_name = "bao-cao-hoan-thanh.txt"
    safe_name = f"{task_id}_{file_name}"
    path = UPLOAD_DIR / safe_name
    content = "Bao cao cong viec mau: cong viec da duoc hoan thanh.\n".encode("utf-8")
    path.write_bytes(content)
    return {"name": file_name, "path": safe_name, "size": len(content)}


def seed_users(db: sqlite3.Connection) -> None:
    now = now_iso()
    rows = [
        ("Minh", "minh", "minh@example.com", "manager"),
        ("An", "an", "an@example.com", "member"),
        ("Linh", "linh", "linh@example.com", "member"),
        ("Huy", "huy", "huy@example.com", "admin"),
    ]
    for display_name, username, email, role in rows:
        db.execute(
            """
            INSERT INTO users
              (id, display_name, username, email, role, is_active, password_hash,
               password_changed_at, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?, ?)
            """,
            (str(uuid.uuid4()), display_name, username, email, role, hash_password("ChangeMe123!"), now, now, now),
        )


class KanbanHandler(BaseHTTPRequestHandler):
    server_version = "KanbanServer/1.1"

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.send_common_headers()
        self.end_headers()

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/api/tasks":
            self.send_json(list_tasks())
            return
        parts = api_parts(self.path)
        if len(parts) == 3 and parts[0] == "tasks" and parts[2] == "report":
            self.serve_report(parts[1])
            return
        if path == "/api/users":
            self.send_json(list_users())
            return
        self.serve_static(path)

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path == "/api/tasks":
            self.send_json(create_task(self.read_json()), status=201)
            return
        if path == "/api/users":
            self.send_json(create_user(self.read_json()), status=201)
            return
        self.send_json({"error": "Không tìm thấy API"}, status=404)

    def do_PUT(self) -> None:
        parts = api_parts(self.path)
        if len(parts) == 2 and parts[0] == "tasks":
            self.send_json(update_task(parts[1], self.read_json()))
            return
        if len(parts) == 2 and parts[0] == "users":
            self.send_json(update_user(parts[1], self.read_json()))
            return
        self.send_json({"error": "Không tìm thấy API"}, status=404)

    def do_PATCH(self) -> None:
        parts = api_parts(self.path)
        if len(parts) == 3 and parts[0] == "tasks" and parts[2] == "status":
            payload = self.read_json()
            self.send_json(update_task_status(parts[1], payload.get("status", "")))
            return
        self.send_json({"error": "Không tìm thấy API"}, status=404)

    def do_DELETE(self) -> None:
        parts = api_parts(self.path)
        if len(parts) == 2 and parts[0] == "tasks":
            delete_task(parts[1])
            self.send_json({"ok": True})
            return
        if len(parts) == 2 and parts[0] == "users":
            delete_user(parts[1])
            self.send_json({"ok": True})
            return
        self.send_json({"error": "Không tìm thấy API"}, status=404)

    def serve_static(self, request_path: str) -> None:
        safe_path = unquote(request_path).lstrip("/") or "index.html"
        file_path = (BASE_DIR / safe_path).resolve()
        if BASE_DIR not in file_path.parents and file_path != BASE_DIR:
            self.send_error(403)
            return
        if file_path.is_dir():
            file_path = file_path / "index.html"
        if not file_path.exists():
            file_path = BASE_DIR / "index.html"

        content_type = mimetypes.guess_type(file_path.name)[0] or "application/octet-stream"
        body = file_path.read_bytes()
        self.send_response(200)
        self.send_common_headers()
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def serve_report(self, task_id: str) -> None:
        task = get_task_row(task_id)
        if not task["report_file_path"]:
            raise ApiError("Công việc chưa có file báo cáo", 404)

        file_path = (UPLOAD_DIR / task["report_file_path"]).resolve()
        if UPLOAD_DIR not in file_path.parents or not file_path.exists():
            raise ApiError("Không tìm thấy file báo cáo", 404)

        body = file_path.read_bytes()
        content_type = mimetypes.guess_type(task["report_file_name"])[0] or "application/octet-stream"
        self.send_response(200)
        self.send_common_headers()
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Disposition", f'attachment; filename="{task["report_file_name"]}"')
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        if length == 0:
            return {}
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ApiError("JSON không hợp lệ", 400) from exc

    def send_json(self, data: object, status: int = 200) -> None:
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_common_headers()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_common_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Cache-Control", "no-store")

    def handle_one_request(self) -> None:
        try:
            super().handle_one_request()
        except ApiError as error:
            self.send_json({"error": error.message}, status=error.status)
        except sqlite3.IntegrityError:
            self.send_json({"error": "Username đã tồn tại"}, status=409)

    def log_message(self, format: str, *args: object) -> None:
        print(f"{self.address_string()} - {format % args}")


class ApiError(Exception):
    def __init__(self, message: str, status: int = 400) -> None:
        super().__init__(message)
        self.message = message
        self.status = status


def api_parts(path: str) -> list[str]:
    parsed = urlparse(path).path.strip("/").split("/")
    return parsed[1:] if parsed and parsed[0] == "api" else []


def list_tasks() -> list[dict]:
    with connect() as db:
        rows = db.execute("SELECT * FROM tasks ORDER BY created_at DESC").fetchall()
    return [serialize_task(row) for row in rows]


def create_task(payload: dict) -> dict:
    task = normalize_task_payload(payload)
    now = now_iso()
    task_id = str(uuid.uuid4())
    report = save_report_file(task_id, payload.get("reportFile"))
    if task["status"] == "done" and not report:
        raise ApiError("Cần đính kèm file báo cáo trước khi hoàn thành công việc")
    report = report or {"name": "", "path": "", "size": 0}
    with connect() as db:
        db.execute(
            """
            INSERT INTO tasks
              (id, title, description, status, priority, owner, due_date, tags,
               report_file_name, report_file_path, report_file_size, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                task_id,
                task["title"],
                task["description"],
                task["status"],
                task["priority"],
                task["owner"],
                task["due_date"],
                json.dumps(task["tags"]),
                report["name"],
                report["path"],
                report["size"],
                now,
                now,
            ),
        )
        row = db.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
    return serialize_task(row)


def update_task(task_id: str, payload: dict) -> dict:
    current = get_task_row(task_id)
    task = normalize_task_payload(payload)
    now = now_iso()
    report = save_report_file(task_id, payload.get("reportFile"))
    if task["status"] == "done" and not report and not current["report_file_path"]:
        raise ApiError("Cần đính kèm file báo cáo trước khi hoàn thành công việc")

    with connect() as db:
        if report:
            db.execute(
                """
                UPDATE tasks
                SET title = ?, description = ?, status = ?, priority = ?, owner = ?,
                    due_date = ?, tags = ?, report_file_name = ?, report_file_path = ?,
                    report_file_size = ?, updated_at = ?
                WHERE id = ?
                """,
                (
                    task["title"],
                    task["description"],
                    task["status"],
                    task["priority"],
                    task["owner"],
                    task["due_date"],
                    json.dumps(task["tags"]),
                    report["name"],
                    report["path"],
                    report["size"],
                    now,
                    task_id,
                ),
            )
        else:
            db.execute(
                """
                UPDATE tasks
                SET title = ?, description = ?, status = ?, priority = ?, owner = ?,
                    due_date = ?, tags = ?, updated_at = ?
                WHERE id = ?
                """,
                (
                    task["title"],
                    task["description"],
                    task["status"],
                    task["priority"],
                    task["owner"],
                    task["due_date"],
                    json.dumps(task["tags"]),
                    now,
                    task_id,
                ),
            )
        row = db.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
    if report:
        delete_report_file(current["report_file_path"])
    return serialize_task(row)


def update_task_status(task_id: str, status: str) -> dict:
    current = get_task_row(task_id)
    if status not in COLUMNS:
        raise ApiError("Trạng thái không hợp lệ")
    if status == "done" and not current["report_file_path"]:
        raise ApiError("Cần đính kèm file báo cáo trước khi hoàn thành công việc")
    with connect() as db:
        db.execute("UPDATE tasks SET status = ?, updated_at = ? WHERE id = ?", (status, now_iso(), task_id))
        row = db.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
    return serialize_task(row)


def delete_task(task_id: str) -> None:
    task = get_task_row(task_id)
    with connect() as db:
        db.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
    delete_report_file(task["report_file_path"])


def list_users() -> list[dict]:
    with connect() as db:
        rows = db.execute("SELECT * FROM users ORDER BY created_at DESC").fetchall()
    return [serialize_user(row) for row in rows]


def create_user(payload: dict) -> dict:
    user = normalize_user_payload(payload, require_password=True)
    user_id = str(uuid.uuid4())
    now = now_iso()
    password_hash = hash_password(user["password"])
    with connect() as db:
        db.execute(
            """
            INSERT INTO users
              (id, display_name, username, email, role, is_active, password_hash,
               password_changed_at, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                user_id,
                user["display_name"],
                user["username"],
                user["email"],
                user["role"],
                int(user["is_active"]),
                password_hash,
                now,
                now,
                now,
            ),
        )
        row = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    return serialize_user(row)


def update_user(user_id: str, payload: dict) -> dict:
    ensure_user_exists(user_id)
    user = normalize_user_payload(payload, require_password=False)
    now = now_iso()
    with connect() as db:
        if user["password"]:
            db.execute(
                """
                UPDATE users
                SET display_name = ?, username = ?, email = ?, role = ?, is_active = ?,
                    password_hash = ?, password_changed_at = ?, updated_at = ?
                WHERE id = ?
                """,
                (
                    user["display_name"],
                    user["username"],
                    user["email"],
                    user["role"],
                    int(user["is_active"]),
                    hash_password(user["password"]),
                    now,
                    now,
                    user_id,
                ),
            )
        else:
            db.execute(
                """
                UPDATE users
                SET display_name = ?, username = ?, email = ?, role = ?, is_active = ?, updated_at = ?
                WHERE id = ?
                """,
                (
                    user["display_name"],
                    user["username"],
                    user["email"],
                    user["role"],
                    int(user["is_active"]),
                    now,
                    user_id,
                ),
            )
        row = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    return serialize_user(row)


def delete_user(user_id: str) -> None:
    ensure_user_exists(user_id)
    with connect() as db:
        if db.execute("SELECT COUNT(*) FROM users").fetchone()[0] <= 1:
            raise ApiError("Không thể xóa user cuối cùng")
        db.execute("DELETE FROM users WHERE id = ?", (user_id,))


def normalize_task_payload(payload: dict) -> dict:
    title = str(payload.get("title", "")).strip()
    if not title:
        raise ApiError("Tiêu đề là bắt buộc")

    status = str(payload.get("status", "backlog")).strip()
    priority = str(payload.get("priority", "medium")).strip()
    due_date = str(payload.get("dueDate", "")).strip()
    tags = payload.get("tags", [])

    if status not in COLUMNS:
        raise ApiError("Trạng thái không hợp lệ")
    if priority not in PRIORITIES:
        raise ApiError("Ưu tiên không hợp lệ")
    if due_date:
        try:
            date.fromisoformat(due_date)
        except ValueError as exc:
            raise ApiError("Hạn hoàn thành không hợp lệ") from exc
    if not isinstance(tags, list):
        raise ApiError("Nhãn phải là danh sách")

    return {
        "title": title[:90],
        "description": str(payload.get("description", "")).strip()[:360],
        "status": status,
        "priority": priority,
        "owner": str(payload.get("owner", "")).strip()[:80],
        "due_date": due_date,
        "tags": [str(tag).strip()[:30] for tag in tags if str(tag).strip()][:12],
    }


def normalize_user_payload(payload: dict, require_password: bool) -> dict:
    display_name = str(payload.get("displayName", "")).strip()
    username = str(payload.get("username", "")).strip().lower()
    email = str(payload.get("email", "")).strip().lower()
    role = str(payload.get("role", "member")).strip()
    password = str(payload.get("password", ""))

    if not display_name:
        raise ApiError("Tên hiển thị là bắt buộc")
    if not username:
        raise ApiError("Username là bắt buộc")
    if not username.replace("_", "").replace("-", "").isalnum():
        raise ApiError("Username chỉ nên chứa chữ, số, dấu gạch ngang hoặc gạch dưới")
    if role not in ROLES:
        raise ApiError("Vai trò không hợp lệ")
    if require_password and not password:
        raise ApiError("Mật khẩu là bắt buộc")
    if password and len(password) < 8:
        raise ApiError("Mật khẩu phải có ít nhất 8 ký tự")

    return {
        "display_name": display_name[:80],
        "username": username[:40],
        "email": email[:120],
        "role": role,
        "is_active": bool(payload.get("isActive", True)),
        "password": password,
    }


def ensure_task_exists(task_id: str) -> None:
    with connect() as db:
        row = db.execute("SELECT id FROM tasks WHERE id = ?", (task_id,)).fetchone()
    if row is None:
        raise ApiError("Không tìm thấy công việc", 404)


def get_task_row(task_id: str) -> sqlite3.Row:
    with connect() as db:
        row = db.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
    if row is None:
        raise ApiError("Không tìm thấy công việc", 404)
    return row


def save_report_file(task_id: str, report: object) -> dict | None:
    if not report:
        return None
    if not isinstance(report, dict):
        raise ApiError("File báo cáo không hợp lệ")

    name = Path(str(report.get("name", ""))).name.strip()
    content = str(report.get("content", ""))
    size = int(report.get("size", 0) or 0)
    if not name or not content:
        raise ApiError("File báo cáo không hợp lệ")
    if size > 10 * 1024 * 1024:
        raise ApiError("File báo cáo tối đa 10MB")

    try:
        body = base64.b64decode(content, validate=True)
    except Exception as exc:
        raise ApiError("Nội dung file báo cáo không hợp lệ") from exc

    safe_name = "".join(char if char.isalnum() or char in ".-_" else "_" for char in name)[:120]
    stored_name = f"{task_id}_{uuid.uuid4().hex}_{safe_name}"
    path = UPLOAD_DIR / stored_name
    path.write_bytes(body)
    return {"name": name[:180], "path": stored_name, "size": len(body)}


def delete_report_file(stored_name: str) -> None:
    if not stored_name:
        return
    file_path = (UPLOAD_DIR / stored_name).resolve()
    if UPLOAD_DIR in file_path.parents and file_path.exists():
        file_path.unlink()


def ensure_user_exists(user_id: str) -> None:
    with connect() as db:
        row = db.execute("SELECT id FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None:
        raise ApiError("Không tìm thấy user", 404)


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return "pbkdf2_sha256${}${}${}".format(
        PBKDF2_ITERATIONS,
        base64.b64encode(salt).decode("ascii"),
        base64.b64encode(digest).decode("ascii"),
    )


def verify_password(password: str, encoded: str) -> bool:
    try:
        algorithm, iterations, salt_text, digest_text = encoded.split("$", 3)
        if algorithm != "pbkdf2_sha256":
            return False
        salt = base64.b64decode(salt_text)
        expected = base64.b64decode(digest_text)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, int(iterations))
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False


def now_iso() -> str:
    return datetime.utcnow().isoformat(timespec="seconds")


def serialize_task(row: sqlite3.Row) -> dict:
    return {
        "id": row["id"],
        "title": row["title"],
        "description": row["description"],
        "status": row["status"],
        "priority": row["priority"],
        "owner": row["owner"],
        "dueDate": row["due_date"],
        "tags": json.loads(row["tags"]),
        "reportFileName": row["report_file_name"],
        "reportFileSize": row["report_file_size"],
        "createdAt": row["created_at"],
        "updatedAt": row["updated_at"],
    }


def serialize_user(row: sqlite3.Row) -> dict:
    return {
        "id": row["id"],
        "displayName": row["display_name"],
        "username": row["username"],
        "email": row["email"],
        "role": row["role"],
        "isActive": bool(row["is_active"]),
        "passwordChangedAt": row["password_changed_at"],
        "createdAt": row["created_at"],
        "updatedAt": row["updated_at"],
    }


if __name__ == "__main__":
    main()
