# Kanban Công Việc

Ứng dụng quản lý công việc Kanban có frontend HTML/CSS/JavaScript, backend Python và database SQLite.

## Chức năng

- Bảng công việc Kanban: thêm, sửa, xóa, kéo thả đổi trạng thái.
- Khi hoàn thành công việc, bắt buộc phải đính kèm file báo cáo.
- Báo cáo: tổng số việc, tỉ lệ hoàn thành, việc quá hạn, thống kê theo trạng thái và ưu tiên.
- Nhóm: danh sách thành viên đang hoạt động và khối lượng công việc theo từng người.
- User: tạo, sửa, khóa/mở user, xóa user và đổi mật khẩu.
- Mật khẩu được hash bằng PBKDF2-SHA256 trước khi lưu vào SQLite.

## Chạy trên máy

Yêu cầu: Python 3.

```powershell
py server.py
```

Sau đó mở:

```text
http://127.0.0.1:8000
```

Database sẽ tự tạo tại:

```text
data/kanban.sqlite3
```

File báo cáo đính kèm được lưu tại:

```text
data/uploads
```

## API

- `GET /api/tasks`: lấy danh sách công việc
- `POST /api/tasks`: tạo công việc
- `PUT /api/tasks/{id}`: cập nhật công việc, có thể kèm `reportFile`
- `PATCH /api/tasks/{id}/status`: đổi trạng thái khi kéo thả
- `DELETE /api/tasks/{id}`: xóa công việc
- `GET /api/tasks/{id}/report`: tải file báo cáo hoàn thành
- `GET /api/users`: lấy danh sách user
- `POST /api/users`: tạo user
- `PUT /api/users/{id}`: cập nhật thông tin user hoặc đổi mật khẩu
- `DELETE /api/users/{id}`: xóa user

## Publish lên web

Bản này có backend và database, vì vậy không thể publish bằng Netlify Drop/Vercel static hosting đơn thuần. Cần deploy như một Python web service.

### Render

1. Đưa toàn bộ thư mục này lên GitHub repository.
2. Vào https://render.com và tạo `Web Service`.
3. Kết nối repository.
4. Runtime: Python.
5. Build command: để trống.
6. Start command: `python server.py`
7. Thêm persistent disk nếu muốn giữ database SQLite và file đính kèm lâu dài:
   - Mount path: đường dẫn tới thư mục `data` trong app.
   - Database file: `data/kanban.sqlite3`
   - Upload folder: `data/uploads`

### VPS hoặc server riêng

Chạy:

```bash
python server.py
```

Đặt reverse proxy như Nginx/Caddy trỏ domain về port của app, ví dụ `8000`.

## Lưu ý dữ liệu

SQLite phù hợp cho app nhỏ hoặc nhóm nội bộ. Bản hiện tại có quản lý user và hash mật khẩu, nhưng chưa có màn hình đăng nhập/session/permission enforcement. Nếu publish public, nên thêm xác thực đăng nhập, phân quyền API và HTTPS trước khi dùng thật.
