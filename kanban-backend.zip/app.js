const API_BASE = "/api";

const columns = [
  { id: "backlog", title: "Cần làm", color: "#6e7f91" },
  { id: "doing", title: "Đang làm", color: "#1b7f68" },
  { id: "review", title: "Đang duyệt", color: "#c77918" },
  { id: "done", title: "Hoàn thành", color: "#537c46" },
];

const priorityLabels = { low: "Thấp", medium: "Vừa", high: "Cao" };
const roleLabels = { admin: "Admin", manager: "Manager", member: "Member" };

let tasks = [];
let users = [];
let activeTaskId = null;
let activeUserId = null;
let draggedTaskId = null;
let activeView = "board";

const board = document.querySelector("#board");
const reports = document.querySelector("#reports");
const team = document.querySelector("#team");
const usersPanel = document.querySelector("#users");
const searchInput = document.querySelector("#searchInput");
const pageTitle = document.querySelector("#pageTitle");
const pageEyebrow = document.querySelector("#pageEyebrow");
const boardActions = document.querySelector("#boardActions");
const userActions = document.querySelector("#userActions");

const taskDialog = document.querySelector("#taskDialog");
const taskForm = document.querySelector("#taskForm");
const taskIdInput = document.querySelector("#taskId");
const taskTitleInput = document.querySelector("#taskTitle");
const taskDescriptionInput = document.querySelector("#taskDescription");
const taskStatusInput = document.querySelector("#taskStatus");
const taskPriorityInput = document.querySelector("#taskPriority");
const taskOwnerInput = document.querySelector("#taskOwner");
const taskDueDateInput = document.querySelector("#taskDueDate");
const taskTagsInput = document.querySelector("#taskTags");
const taskReportFileInput = document.querySelector("#taskReportFile");
const taskReportCurrent = document.querySelector("#taskReportCurrent");
const dialogTitle = document.querySelector("#dialogTitle");
const deleteTaskBtn = document.querySelector("#deleteTaskBtn");

const userDialog = document.querySelector("#userDialog");
const userForm = document.querySelector("#userForm");
const userDialogTitle = document.querySelector("#userDialogTitle");
const userIdInput = document.querySelector("#userId");
const displayNameInput = document.querySelector("#displayName");
const usernameInput = document.querySelector("#username");
const emailInput = document.querySelector("#email");
const roleInput = document.querySelector("#role");
const isActiveInput = document.querySelector("#isActive");
const passwordInput = document.querySelector("#password");
const deleteUserBtn = document.querySelector("#deleteUserBtn");

async function initialize() {
  taskStatusInput.innerHTML = columns.map((column) => `<option value="${column.id}">${column.title}</option>`).join("");
  document.querySelector("#addTaskBtn").addEventListener("click", () => openTaskDialog());
  document.querySelector("#addUserBtn").addEventListener("click", () => openUserDialog());
  document.querySelector("#closeDialogBtn").addEventListener("click", closeTaskDialog);
  document.querySelector("#cancelDialogBtn").addEventListener("click", closeTaskDialog);
  document.querySelector("#closeUserDialogBtn").addEventListener("click", closeUserDialog);
  document.querySelector("#cancelUserDialogBtn").addEventListener("click", closeUserDialog);
  deleteTaskBtn.addEventListener("click", deleteActiveTask);
  deleteUserBtn.addEventListener("click", deleteActiveUser);
  searchInput.addEventListener("input", renderBoard);
  taskForm.addEventListener("submit", saveTaskFromForm);
  userForm.addEventListener("submit", saveUserFromForm);
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.addEventListener("click", () => setView(item.dataset.view));
  });
  await loadData();
}

async function loadData() {
  try {
    const [taskRows, userRows] = await Promise.all([requestJson("/tasks"), requestJson("/users")]);
    tasks = taskRows;
    users = userRows;
    renderAll();
  } catch (error) {
    showBoardError(error.message);
  }
}

function setView(view) {
  activeView = view;
  document.querySelectorAll(".nav-item").forEach((item) => item.classList.toggle("active", item.dataset.view === view));
  document.querySelectorAll(".view").forEach((item) => item.classList.remove("active-view"));
  document.querySelector(`#${view}View`).classList.add("active-view");
  boardActions.classList.toggle("hidden", view !== "board");
  userActions.classList.toggle("hidden", view !== "users");

  const titles = {
    board: ["Không gian sản phẩm", "Bảng triển khai sprint"],
    reports: ["Phân tích tiến độ", "Báo cáo công việc"],
    team: ["Nguồn lực nhóm", "Nhóm thực hiện"],
    users: ["Quản trị hệ thống", "Quản lý user"],
  };
  pageEyebrow.textContent = titles[view][0];
  pageTitle.textContent = titles[view][1];
}

function renderAll() {
  renderOwnerOptions();
  renderBoard();
  renderReports();
  renderTeam();
  renderUsers();
  updateMetrics();
}

function renderOwnerOptions() {
  const activeUsers = users.filter((user) => user.isActive);
  taskOwnerInput.innerHTML = [
    `<option value="">Chưa giao</option>`,
    ...activeUsers.map((user) => `<option value="${escapeHtml(user.displayName)}">${escapeHtml(user.displayName)}</option>`),
  ].join("");
}

function renderBoard() {
  const query = searchInput.value.trim().toLowerCase();
  const visibleTasks = tasks.filter((task) => matchesQuery(task, query));

  board.innerHTML = columns
    .map((column) => {
      const columnTasks = visibleTasks.filter((task) => task.status === column.id);
      return `
        <article class="column" data-column-id="${column.id}">
          <header class="column-header">
            <div class="column-title">
              <span class="column-dot" style="background:${column.color}"></span>
              <span>${column.title}</span>
            </div>
            <span class="pill">${columnTasks.length}</span>
          </header>
          <div class="task-list" data-list-id="${column.id}">
            ${columnTasks.length ? columnTasks.map(renderTask).join("") : `<div class="empty-state">Chưa có công việc</div>`}
          </div>
        </article>
      `;
    })
    .join("");

  wireBoardEvents();
  updateMetrics();
}

function renderTask(task) {
  const tags = task.tags.map((tag) => `<span class="pill">${escapeHtml(tag)}</span>`).join("");
  const dueText = task.dueDate ? formatDate(task.dueDate) : "Chưa có hạn";
  const owner = task.owner ? escapeHtml(task.owner) : "Chưa giao";
  const reportLink = task.reportFileName
    ? `<a class="pill" href="/api/tasks/${task.id}/report" target="_blank" rel="noreferrer">Báo cáo: ${escapeHtml(task.reportFileName)}</a>`
    : "";

  return `
    <article class="task-card" draggable="true" data-task-id="${task.id}" tabindex="0">
      <div class="task-meta">
        <span class="pill priority-${task.priority}">${priorityLabels[task.priority]}</span>
        <span class="pill">${dueText}</span>
      </div>
      <h3>${escapeHtml(task.title)}</h3>
      ${task.description ? `<p>${escapeHtml(task.description)}</p>` : ""}
      <div class="task-tags">${tags}</div>
      <div class="task-meta"><span class="pill">${owner}</span>${reportLink}</div>
    </article>
  `;
}

function renderReports() {
  const total = tasks.length;
  const done = countTasks((task) => task.status === "done");
  const overdue = countTasks((task) => task.status !== "done" && isOverdue(task.dueDate));
  const completion = total ? Math.round((done / total) * 100) : 0;
  const byStatus = columns.map((column) => ({ label: column.title, value: countTasks((task) => task.status === column.id) }));
  const byPriority = ["high", "medium", "low"].map((priority) => ({
    label: priorityLabels[priority],
    value: countTasks((task) => task.priority === priority),
  }));

  reports.innerHTML = `
    <article class="report-card">
      <h3>Tổng công việc</h3>
      <div class="report-value">${total}</div>
      <p class="form-note">${done} việc đã hoàn thành</p>
    </article>
    <article class="report-card">
      <h3>Tỉ lệ hoàn thành</h3>
      <div class="report-value">${completion}%</div>
      <p class="form-note">Dựa trên toàn bộ công việc trong database</p>
    </article>
    <article class="report-card">
      <h3>Quá hạn</h3>
      <div class="report-value">${overdue}</div>
      <p class="form-note">Không tính công việc đã hoàn thành</p>
    </article>
    <article class="report-card wide">
      <h3>Theo trạng thái</h3>
      ${renderBars(byStatus, total)}
    </article>
    <article class="report-card">
      <h3>Theo ưu tiên</h3>
      ${renderBars(byPriority, total)}
    </article>
  `;
}

function renderBars(rows, total) {
  return `
    <div class="bar-list">
      ${rows
        .map((row) => {
          const width = total ? Math.round((row.value / total) * 100) : 0;
          return `
            <div class="bar-row">
              <span>${escapeHtml(row.label)}</span>
              <div class="bar-track"><div class="bar-fill" style="width:${width}%"></div></div>
              <strong>${row.value}</strong>
            </div>
          `;
        })
        .join("")}
    </div>
  `;
}

function renderTeam() {
  const activeUsers = users.filter((user) => user.isActive);
  team.innerHTML = activeUsers.length
    ? activeUsers.map(renderMember).join("")
    : `<div class="empty-state">Chưa có thành viên đang hoạt động</div>`;
}

function renderMember(user) {
  const assigned = tasks.filter((task) => task.owner === user.displayName);
  const done = assigned.filter((task) => task.status === "done").length;
  const open = assigned.length - done;
  const overdue = assigned.filter((task) => task.status !== "done" && isOverdue(task.dueDate)).length;

  return `
    <article class="member-card">
      <div class="member-head">
        <div class="avatar">${escapeHtml(initials(user.displayName))}</div>
        <div>
          <h3>${escapeHtml(user.displayName)}</h3>
          <p class="form-note">${escapeHtml(roleLabels[user.role] || user.role)} · ${escapeHtml(user.email || "Chưa có email")}</p>
        </div>
      </div>
      <div class="member-stats">
        <span><strong>${open}</strong>Đang mở</span>
        <span><strong>${done}</strong>Hoàn thành</span>
        <span><strong>${overdue}</strong>Quá hạn</span>
      </div>
    </article>
  `;
}

function renderUsers() {
  usersPanel.innerHTML = `
    <table class="data-table">
      <thead>
        <tr>
          <th>Tên</th>
          <th>Username</th>
          <th>Email</th>
          <th>Vai trò</th>
          <th>Trạng thái</th>
          <th>Cập nhật</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        ${
          users.length
            ? users.map(renderUserRow).join("")
            : `<tr><td colspan="7">Chưa có user</td></tr>`
        }
      </tbody>
    </table>
  `;

  usersPanel.querySelectorAll("[data-edit-user]").forEach((button) => {
    button.addEventListener("click", () => openUserDialog(button.dataset.editUser));
  });
}

function renderUserRow(user) {
  return `
    <tr>
      <td>${escapeHtml(user.displayName)}</td>
      <td>${escapeHtml(user.username)}</td>
      <td>${escapeHtml(user.email || "")}</td>
      <td>${escapeHtml(roleLabels[user.role] || user.role)}</td>
      <td><span class="pill ${user.isActive ? "status-active" : "status-locked"}">${user.isActive ? "Đang hoạt động" : "Tạm khóa"}</span></td>
      <td>${formatDateTime(user.updatedAt)}</td>
      <td><button class="small-btn" type="button" data-edit-user="${user.id}">Sửa</button></td>
    </tr>
  `;
}

function matchesQuery(task, query) {
  if (!query) return true;
  const content = [task.title, task.description, task.owner, task.priority, ...task.tags].join(" ").toLowerCase();
  return content.includes(query);
}

function wireBoardEvents() {
  document.querySelectorAll(".task-card").forEach((card) => {
    card.addEventListener("click", () => openTaskDialog(card.dataset.taskId));
    card.addEventListener("keydown", (event) => {
      if (event.key === "Enter") openTaskDialog(card.dataset.taskId);
    });
    card.addEventListener("dragstart", () => {
      draggedTaskId = card.dataset.taskId;
      card.classList.add("dragging");
    });
    card.addEventListener("dragend", () => {
      draggedTaskId = null;
      card.classList.remove("dragging");
      document.querySelectorAll(".column").forEach((column) => column.classList.remove("drag-over"));
    });
  });

  document.querySelectorAll(".column").forEach((column) => {
    column.addEventListener("dragover", (event) => {
      event.preventDefault();
      column.classList.add("drag-over");
    });
    column.addEventListener("dragleave", () => column.classList.remove("drag-over"));
    column.addEventListener("drop", async () => {
      if (!draggedTaskId) return;
      await moveTask(draggedTaskId, column.dataset.columnId);
      column.classList.remove("drag-over");
    });
  });
}

function openTaskDialog(taskId = null) {
  activeTaskId = taskId;
  const task = tasks.find((item) => item.id === taskId);

  dialogTitle.textContent = task ? "Chỉnh sửa công việc" : "Thêm công việc";
  deleteTaskBtn.hidden = !task;
  taskIdInput.value = task?.id ?? "";
  taskTitleInput.value = task?.title ?? "";
  taskDescriptionInput.value = task?.description ?? "";
  taskStatusInput.value = task?.status ?? "backlog";
  taskPriorityInput.value = task?.priority ?? "medium";
  taskOwnerInput.value = task?.owner ?? "";
  taskDueDateInput.value = task?.dueDate ?? "";
  taskTagsInput.value = task?.tags.join(", ") ?? "";
  taskReportFileInput.value = "";
  taskReportCurrent.innerHTML = task?.reportFileName
    ? `Báo cáo hiện tại: <a href="/api/tasks/${task.id}/report" target="_blank" rel="noreferrer">${escapeHtml(task.reportFileName)}</a>`
    : "Chưa có file báo cáo.";
  taskDialog.showModal();
  taskTitleInput.focus();
}

function closeTaskDialog() {
  taskDialog.close();
  taskForm.reset();
  activeTaskId = null;
}

async function saveTaskFromForm(event) {
  event.preventDefault();

  const payload = {
    title: taskTitleInput.value.trim(),
    description: taskDescriptionInput.value.trim(),
    status: taskStatusInput.value,
    priority: taskPriorityInput.value,
    owner: taskOwnerInput.value.trim(),
    dueDate: taskDueDateInput.value,
    tags: taskTagsInput.value.split(",").map((tag) => tag.trim()).filter(Boolean),
  };

  if (!payload.title) return;
  const currentTask = tasks.find((task) => task.id === activeTaskId);
  if (payload.status === "done" && !currentTask?.reportFileName && !taskReportFileInput.files.length) {
    alert("Cần đính kèm file báo cáo trước khi hoàn thành công việc.");
    return;
  }

  if (taskReportFileInput.files.length) {
    payload.reportFile = await readSelectedReportFile();
  }

  try {
    const savedTask = activeTaskId
      ? await requestJson(`/tasks/${activeTaskId}`, "PUT", payload)
      : await requestJson("/tasks", "POST", payload);
    tasks = activeTaskId ? tasks.map((task) => (task.id === activeTaskId ? savedTask : task)) : [savedTask, ...tasks];
    closeTaskDialog();
    renderAll();
  } catch (error) {
    alert(error.message);
  }
}

async function deleteActiveTask() {
  if (!activeTaskId) return;

  try {
    await requestJson(`/tasks/${activeTaskId}`, "DELETE");
    tasks = tasks.filter((task) => task.id !== activeTaskId);
    closeTaskDialog();
    renderAll();
  } catch (error) {
    alert(error.message);
  }
}

async function moveTask(taskId, status) {
  const task = tasks.find((item) => item.id === taskId);
  if (status === "done" && !task?.reportFileName) {
    alert("Cần mở công việc và đính kèm file báo cáo trước khi chuyển sang Hoàn thành.");
    openTaskDialog(taskId);
    taskStatusInput.value = "done";
    return;
  }

  const previousTasks = tasks;
  tasks = tasks.map((task) => (task.id === taskId ? { ...task, status } : task));
  renderAll();

  try {
    const updatedTask = await requestJson(`/tasks/${taskId}/status`, "PATCH", { status });
    tasks = tasks.map((task) => (task.id === taskId ? updatedTask : task));
    renderAll();
  } catch (error) {
    tasks = previousTasks;
    renderAll();
    alert(error.message);
  }
}

function openUserDialog(userId = null) {
  activeUserId = userId;
  const user = users.find((item) => item.id === userId);

  userDialogTitle.textContent = user ? "Chỉnh sửa user" : "Thêm user";
  deleteUserBtn.hidden = !user;
  passwordInput.required = !user;
  userIdInput.value = user?.id ?? "";
  displayNameInput.value = user?.displayName ?? "";
  usernameInput.value = user?.username ?? "";
  emailInput.value = user?.email ?? "";
  roleInput.value = user?.role ?? "member";
  isActiveInput.value = user?.isActive ? "1" : "0";
  passwordInput.value = "";
  userDialog.showModal();
  displayNameInput.focus();
}

function closeUserDialog() {
  userDialog.close();
  userForm.reset();
  activeUserId = null;
}

async function saveUserFromForm(event) {
  event.preventDefault();

  const payload = {
    displayName: displayNameInput.value.trim(),
    username: usernameInput.value.trim(),
    email: emailInput.value.trim(),
    role: roleInput.value,
    isActive: isActiveInput.value === "1",
    password: passwordInput.value,
  };

  if (!payload.password) delete payload.password;

  try {
    const savedUser = activeUserId
      ? await requestJson(`/users/${activeUserId}`, "PUT", payload)
      : await requestJson("/users", "POST", payload);
    users = activeUserId ? users.map((user) => (user.id === activeUserId ? savedUser : user)) : [savedUser, ...users];
    closeUserDialog();
    renderAll();
  } catch (error) {
    alert(error.message);
  }
}

async function deleteActiveUser() {
  if (!activeUserId) return;

  try {
    await requestJson(`/users/${activeUserId}`, "DELETE");
    users = users.filter((user) => user.id !== activeUserId);
    closeUserDialog();
    renderAll();
  } catch (error) {
    alert(error.message);
  }
}

async function requestJson(path, method = "GET", body = null) {
  const options = { method, headers: { "Content-Type": "application/json" } };
  if (body) options.body = JSON.stringify(body);

  const response = await fetch(`${API_BASE}${path}`, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Không thể kết nối backend");
  return data;
}

function updateMetrics() {
  const done = countTasks((task) => task.status === "done");
  const open = tasks.length - done;
  const dueSoon = countTasks((task) => task.status !== "done" && isDueSoon(task.dueDate));
  const percentDone = tasks.length ? Math.round((done / tasks.length) * 100) : 0;

  document.querySelector("#openCount").textContent = open;
  document.querySelector("#dueSoonCount").textContent = dueSoon;
  document.querySelector("#doneCount").textContent = done;
  document.querySelector("#summaryText").textContent = `${open} việc đang mở`;
  document.querySelector("#progressBar").style.width = `${percentDone}%`;
}

function countTasks(predicate) {
  return tasks.filter(predicate).length;
}

function isDueSoon(dateValue) {
  if (!dateValue) return false;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const dueDate = new Date(`${dateValue}T00:00:00`);
  const diff = Math.ceil((dueDate - today) / 86_400_000);
  return diff >= 0 && diff <= 3;
}

function isOverdue(dateValue) {
  if (!dateValue) return false;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return new Date(`${dateValue}T00:00:00`) < today;
}

function formatDate(dateValue) {
  return new Intl.DateTimeFormat("vi-VN", { day: "2-digit", month: "2-digit", year: "numeric" }).format(
    new Date(`${dateValue}T00:00:00`),
  );
}

function formatDateTime(value) {
  if (!value) return "";
  return new Intl.DateTimeFormat("vi-VN", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(value));
}

function initials(name) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(-2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();
}

function readSelectedReportFile() {
  const file = taskReportFileInput.files[0];
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.addEventListener("load", () => {
      const result = String(reader.result);
      resolve({
        name: file.name,
        type: file.type,
        size: file.size,
        content: result.includes(",") ? result.split(",")[1] : result,
      });
    });
    reader.addEventListener("error", () => reject(new Error("Không thể đọc file báo cáo")));
    reader.readAsDataURL(file);
  });
}

function showBoardError(message) {
  board.innerHTML = `<div class="empty-state">${escapeHtml(message)}</div>`;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

initialize();
